Check scripts for unagikuma EXEC checks
======================================

Put scripts here and make them executable. Each node runs its own copy:
copy the same script to every node that runs the check.

A script follows the Nagios plugin conventions, so existing plugins work
unchanged:

  exit 0  OK
  exit 1  WARNING   (shown as DEGRADED)
  exit 2  CRITICAL
  exit 3  UNKNOWN

The first output line is the status text; anything after "|" is
performance data (label=value[unit];warn;crit;min;max), kept as metrics.

In monitors.bind:

  disk  IN EXEC check_example args="-w 80 -c 90" device=db1

New script checks start paused. Enable them once the script is on every
node; Settings > Check scripts shows which node lacks it.
